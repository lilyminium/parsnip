#!/usr/bin/env bash

export LD_LIBRARY_PATH=/Users/lily/anaconda3/envs/polytop/lib:$LD_LIBRARY_PATH